# Bloque para publicar en el blog / post de LinkedIn

## Cómo usar este pack en Claude Code

1. Descomprime el ZIP en una carpeta cualquiera de tu ordenador.
2. Abre el terminal (iTerm en Mac, PowerShell en Windows) en esa carpeta y escribe `claude` para arrancar Claude Code.
3. **Arrastra al terminal los tres archivos** de golpe: `LEEME.md`, `prompt.txt` y los tres CSV. Claude Code leerá el contexto completo antes de ejecutar.
4. Pulsa Enter.
5. En cuanto termine, Claude Code te dirá en qué puerto local está sirviendo la web (por ejemplo `http://localhost:8000`). Ábrelo en el navegador y busca el lote `L2024-0847`.
6. El informe PDF para Sanidad se guarda automáticamente en la misma carpeta.

**Importante:** arrastrar el `LEEME.md` junto al `prompt.txt` no es opcional. El LEEME le da a la IA el contexto del sector agroalimentario, la normativa (Reglamento CE 178/2002) y el objetivo del entregable. Sin él, el resultado será más genérico.

Para adaptarlo a tu empresa real, sustituye los CSV de ejemplo por los tuyos exportados del ERP y cambia `[EMPRESA]` y el lote a investigar en el `prompt.txt`.
