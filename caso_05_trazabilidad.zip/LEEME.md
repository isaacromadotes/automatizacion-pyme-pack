# Caso 05 — Trazabilidad de lote en segundos (Agroalimentario)

## El problema real

Recibes una alerta sanitaria de AESAN o de un cliente. Tienes que localizar un lote concreto, saber de qué materias primas venía, cuántas unidades se fabricaron y a qué clientes se enviaron. **Y tienes 24 horas para responder.**

En la mayoría de conserveras, cárnicas, panaderías industriales y bodegas de PYME española esa información está en:
- Un cuaderno del jefe de producción.
- Tres Excel que nadie ha cruzado nunca.
- Un ERP donde nadie sabe hacer el informe.

Resultado: horas o días buscando, riesgo de multa (Reglamento CE 178/2002, art. 18) y pérdida del cliente grande (Mercadona, Consum, Carrefour) por no pasar la próxima auditoría IFS/BRC.

Con Claude Code, la búsqueda del lote y el informe para Sanidad tardan **segundos**.

## Qué contiene este ZIP

- `prompt.txt` — El prompt listo para pegar en Claude Code.
- `entradas_mp.csv` — Registro de entradas de materia prima (12 lotes de proveedores).
- `produccion.csv` — Órdenes de producción (8 lotes de producto terminado).
- `salidas_pt.csv` — Salidas a clientes (15 albaranes cruzando los lotes).
- `LEEME.md` — Este archivo.

Los datos son de una conservera ficticia, **"Conservas del Mediterráneo S.L."**, pero la estructura es la misma que usarás con tus datos reales.

## Cómo usarlo (5 pasos)

1. **Instala Claude Code** siguiendo la guía oficial: https://docs.claude.com/claude-code
2. **Descomprime este ZIP** en una carpeta, por ejemplo:
   `C:\Users\tunombre\Downloads\Trazabilidad\`
3. **Abre el terminal** (iTerm en Mac, PowerShell en Windows) y escribe: `claude`
4. **Copia todo el contenido de `prompt.txt`** y pégalo en Claude Code. Pulsa Enter.
5. Cambia el lote a buscar por el que quieras investigar. En el ejemplo: `L2024-0847`.

Claude Code te devolverá:
- Una web local con buscador de lotes (localhost).
- Un informe PDF listo para Sanidad con trazabilidad hacia atrás (materias primas) y hacia adelante (clientes).

## De dónde sacar los datos en tu ERP

Adapta el formato de las tres tablas a tu sistema:

| Archivo | En A3 ERP | En Sage 200 | En Holded | En SAP Business One | En Odoo |
|---|---|---|---|---|---|
| `entradas_mp.csv` | Compras → Albaranes de compra | Compras → Recepción de mercancía | Inventario → Movimientos entrada | Compras → GRPO | Inventario → Recepciones |
| `produccion.csv` | Producción → Órdenes de fabricación | Producción → Partes de fabricación | (no incluye módulo) | Producción → Órdenes de fabricación | Fabricación → Órdenes |
| `salidas_pt.csv` | Ventas → Albaranes de venta | Ventas → Albaranes | Ventas → Albaranes | Ventas → Entrega | Inventario → Entregas |

**Exporta a CSV** desde cada módulo. Los nombres de columna no tienen que coincidir exactamente: Claude Code las interpreta.

## Importante para tu sector

Este prompt está diseñado específicamente para **agroalimentario** (conservas, cárnicas, lácteos, panadería industrial, bodegas, aceite). Cumple con el estándar mínimo del **Reglamento CE 178/2002** de trazabilidad hacia atrás y hacia adelante ("one step back, one step forward").

Si tu sector es **cosmética, farmacia, químico o pintura**, la estructura sirve pero cambia:
- El campo `temperatura_esterilizacion` por el parámetro crítico de tu proceso (pH, viscosidad, densidad).
- El campo `certificado_calidad` por tu registro de calidad correspondiente (COA, CoC).

Dile a Claude Code el sector al inicio del prompt y él ajusta.

---

Creado por Isaac Romà · https://isaacroma.com
