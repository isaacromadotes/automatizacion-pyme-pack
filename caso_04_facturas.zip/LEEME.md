# Caso 04 — Entrada automática de facturas de proveedor

## El problema

Una gestoría o departamento de administración de 15 personas procesa unas 85 facturas al día. A 3 minutos por factura (abrir PDF, buscar proveedor, asignar cuentas, teclear líneas, cuadrar), son **4 horas y 15 minutos al día tecleando**. Trabajo cualificado desperdiciado en tareas repetitivas.

## Qué hace este prompt

1. Lee una factura en PDF y extrae todos los datos (proveedor, conceptos, importes, IVA)
2. Cruza el CIF del proveedor con tu maestro de proveedores
3. Asigna automáticamente las cuentas contables según tu plan de cuentas
4. Genera el asiento contable completo en formato A3/Holded
5. Alerta si el proveedor tiene facturas pendientes de pago
6. Crea una página web profesional con el asiento maquetado y un CSV listo para importar

## Archivos incluidos

| Archivo | Descripción |
|---------|-------------|
| `prompt.txt` | El prompt que pegarás en Claude Code |
| `factura_proveedor.pdf` | Factura ficticia de ejemplo (Suministros Levante → Asesoría Martínez) |
| `maestro_proveedores.csv` | Maestro de proveedores con CIF, cuentas, forma de pago y pendientes |
| `plan_contable.csv` | Plan General Contable simplificado con cuentas de gasto, IVA y tesorería |
| `LEEME.md` | Este archivo |

## Cómo usarlo paso a paso

### 1. Instala Claude Code (si no lo tienes)
```
npm install -g @anthropic-ai/claude-code
```

### 2. Copia los archivos a una carpeta
Mueve los 3 archivos de datos (`factura_proveedor.pdf`, `maestro_proveedores.csv`, `plan_contable.csv`) a una carpeta. Por ejemplo:
```
C:\Users\TuUsuario\Downloads\Facturas\
```

### 3. Abre Claude Code
```
claude
```

### 4. Pega el prompt
Abre `prompt.txt`, copia todo el contenido y pégalo en Claude Code. **Antes de darle a Enter**, cambia estas variables:

- `[EMPRESA]` → el nombre de tu empresa (ej: "Asesoría García S.L.")
- `[MES AÑO]` → el periodo (ej: "septiembre 2026")
- `@ruta/` → la ruta real donde están tus archivos (ej: `@C:\Users\TuUsuario\Downloads\Facturas\`)

### 5. Dale a Enter y espera
Claude Code leerá la factura, cruzará los datos y generará el asiento. En 30-60 segundos tendrás el resultado.

## De dónde sacar los datos en tu ERP

### Factura del proveedor
- Usa el PDF original que te envía el proveedor por email o que descargas del portal de facturas

### Maestro de proveedores (maestro_proveedores.csv)
- **A3 / A3ERP**: Ficheros → Proveedores → Exportar listado
- **Sage 50/200**: Maestros → Proveedores → Listado → Exportar Excel
- **Holded**: Contactos → Proveedores → Exportar CSV
- **SAP Business One**: Interlocutores comerciales → Proveedores → Exportar
- **Odoo**: Compras → Proveedores → Exportar todo
- **Contaplus/Sage Despachos**: Plan contable → Cuentas de grupo 40 → Exportar

### Plan contable (plan_contable.csv)
- **A3 / A3ERP**: Contabilidad → Plan de cuentas → Exportar
- **Sage 50/200**: Contabilidad → Plan contable → Listado → Exportar
- **Holded**: Contabilidad → Plan de cuentas → Descargar CSV
- **SAP Business One**: Finanzas → Plan de cuentas → Exportar
- **Odoo**: Contabilidad → Configuración → Plan contable → Exportar
- **Contaplus/Sage Despachos**: Plan General Contable → Cuentas → Exportar

## Nota importante

Este prompt está diseñado para **gestorías, asesorías y departamentos de administración** que procesan facturas de proveedores. El plan contable incluido sigue el PGC español (Plan General Contable). Si tu empresa usa un plan sectorial o cuentas personalizadas, sustituye el `plan_contable.csv` por el tuyo.

El asiento generado usa el formato estándar Debe/Haber compatible con la importación de A3, Holded y la mayoría de programas contables españoles.

---

Creado por Isaac Romà · https://isaacroma.com
