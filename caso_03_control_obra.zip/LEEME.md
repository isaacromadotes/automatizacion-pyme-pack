# 🏗️ Control de Costes de Obra en Tiempo Real

## El problema que resuelve

En la mayoría de constructoras y promotoras españolas, el control de costes de obra se hace en un Excel que "alguien actualiza cuando tiene tiempo". El resultado: no sabes si la obra está ganando o perdiendo dinero hasta que termina. Y cuando termina, ya no puedes hacer nada.

Este prompt cruza presupuesto, ejecución real y certificaciones para darte un cuadro de control con semáforo por partida, proyección de coste final y alertas automáticas. En minutos, no en semanas.

---

## Qué contiene este ZIP

| Archivo | Descripción |
|---|---|
| `prompt.txt` | El prompt que pegarás en Claude Code |
| `presupuesto_obra.csv` | Presupuesto por partida (ejemplo: obra de 1.2M€) |
| `costes_reales.csv` | Costes reales ejecutados por partida con % de avance |
| `certificaciones.csv` | Certificaciones mensuales y cobros |
| `LEEME.md` | Este archivo de instrucciones |

---

## Cómo usarlo paso a paso

### 1. Instala Claude Code (si no lo tienes)
```
npm install -g @anthropic-ai/claude-code
```
Necesitas una cuenta en anthropic.com con acceso a Claude Code.

### 2. Prepara tus archivos
Copia los 3 CSVs de ejemplo en una carpeta. Por ejemplo:
```
C:\Users\TuUsuario\Downloads\control_obra\
```

### 3. Abre Claude Code
Abre tu terminal (CMD, PowerShell o iTerm) y escribe:
```
claude
```

### 4. Arrastra o referencia los archivos
Arrastra el archivo `LEEME.md` y `prompt.txt` a la ventana de Claude Code junto con los 3 CSVs. Claude Code leerá el contexto completo antes de ejecutar.

Alternativamente, copia el contenido de `prompt.txt` y pégalo en Claude Code, referenciando los archivos con `@`:
```
@C:\Users\TuUsuario\Downloads\control_obra\presupuesto_obra.csv
@C:\Users\TuUsuario\Downloads\control_obra\costes_reales.csv
@C:\Users\TuUsuario\Downloads\control_obra\certificaciones.csv
```

### 5. Personaliza las variables
Antes de pulsar Enter, cambia:
- `[EMPRESA]` → el nombre de tu constructora/promotora
- `[NOMBRE OBRA]` → el nombre de tu obra
- `[MES AÑO]` → el mes de corte (ej: Septiembre 2026)
- `@ruta/` → la ruta real donde tienes los CSVs

### 6. Pulsa Enter y espera
Claude Code:
1. Validará los datos cruzando los 3 archivos
2. Calculará desviaciones por partida y proyección de coste final
3. Asignará semáforo automático (verde/amarillo/rojo)
4. Generará un dashboard web interactivo
5. Creará un PDF profesional para enviar a dirección

---

## De dónde sacar los datos en tu ERP

### presupuesto_obra.csv
- **A3 Construcción / A3CON**: Módulo de presupuestos → Exportar partidas
- **Presto**: Archivo de presupuesto → Exportar a CSV
- **Sage Despachos / ContaPlus**: Módulo de obras → Presupuesto por capítulos
- **Odoo (módulo construcción)**: Proyecto → Presupuesto → Exportar líneas
- **SAP Business One**: Proyectos → Presupuesto de proyecto → Exportar

### costes_reales.csv
- **A3 Construcción**: Certificaciones de obra → Costes reales por partida
- **Presto**: Seguimiento económico → Exportar ejecución
- **Sage**: Contabilidad analítica → Costes por centro de coste (obra)
- **Odoo**: Partes de obra → Costes ejecutados → Exportar
- **SAP**: Controlling → Costes reales por elemento PEP

### certificaciones.csv
- **A3 Construcción**: Certificaciones mensuales → Exportar
- **Presto**: Certificaciones → Resumen mensual → CSV
- **Sage**: Facturación → Certificaciones emitidas
- **Cualquier ERP**: Facturas emitidas al promotor filtradas por obra

---

## ⚠️ Nota importante

Este prompt está **diseñado específicamente para el sector de la construcción** (promotoras, constructoras, rehabilitación). Los conceptos de partidas, certificaciones y semáforo de desviación son estándar en este sector.

Si trabajas en otro sector y quieres un control de costes de proyecto similar, contacta con Isaac Romà para adaptarlo a tu caso.

---

## Resultado esperado

- **Dashboard web** con semáforo por partida, gráfico presupuesto vs real, y alertas automáticas
- **PDF profesional** listo para enviar a dirección, consejo o propiedad
- **Alertas claras**: qué partidas van mal, cuánto se desvían y qué hacer

---

Creado por Isaac Romà · https://isaacroma.com
