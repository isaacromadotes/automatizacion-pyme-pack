# Caso 02 — Pedidos por email al ERP en segundos

## El problema

En empresas mayoristas y de distribución, alguien del equipo copia pedidos del email (o WhatsApp) al ERP a mano. Línea por línea. Referencia por referencia.

Con 35 pedidos al día y 3 minutos cada uno, son **105 minutos diarios** copiando datos. Y cada vez que se equivoca una referencia, una cantidad o un precio, el error llega al cliente.

## Qué hace este prompt

Claude Code lee el email del cliente, extrae las líneas de pedido, identifica al cliente en tu base de datos, valida cada referencia contra tu catálogo y comprueba el stock disponible. Si algo no cuadra (referencia inexistente, stock insuficiente), lo marca como excepción en lugar de dejarlo pasar.

El resultado es un pedido completo con precios, descuentos, IVA y totales — listo para revisar e introducir al ERP.

**De 3 minutos a 15 segundos. Cero errores de transcripción.**

## Qué contiene este ZIP

| Archivo | Qué es |
|---|---|
| `prompt.txt` | El prompt que pegarás en Claude Code |
| `email_pedido.txt` | Email ficticio de un cliente pidiendo 10 referencias |
| `catalogo_productos.csv` | Catálogo con 20 referencias, precios y familias |
| `stock_actual.csv` | Stock disponible y mínimos por referencia |
| `clientes.csv` | Base de datos de 5 clientes con descuentos y condiciones de pago |
| `LEEME.md` | Este archivo |

## Cómo usarlo paso a paso

### 1. Instala Claude Code (si no lo tienes)
```
npm install -g @anthropic-ai/claude-code
```
Necesitas Node.js 18+ y una cuenta de Anthropic con API key.

### 2. Prepara los archivos
Crea una carpeta (por ejemplo `C:\Users\TuUsuario\Downloads\Ejemplo Claude Code\Vídeo 02\`) y mueve ahí todos los CSV y el email de ejemplo.

### 3. Abre Claude Code
Abre tu terminal (CMD, PowerShell o iTerm en Mac) y escribe:
```
claude
```

### 4. Arrastra el LEEME.md y el prompt.txt
Arrastra ambos archivos a la ventana de Claude Code. Así la IA entiende el contexto completo antes de ejecutar.

### 5. Pega el prompt y personaliza
Abre `prompt.txt`, copia su contenido, y antes de pegar:
- Cambia `[EMPRESA]` por el nombre de tu empresa
- Cambia `@ruta/` por la ruta real de tu carpeta (ej: `@C:\Users\TuUsuario\Downloads\Ejemplo Claude Code\Vídeo 02\`)

### 6. Dale a Enter y espera
Claude Code leerá el email, cruzará datos contra catálogo y stock, y generará el pedido en una web que se abre sola en el navegador.

## De dónde sacar los datos en tu ERP

| Archivo | Dónde encontrarlo |
|---|---|
| `email_pedido.txt` | Tu bandeja de entrada: copia el texto del email del cliente |
| `catalogo_productos.csv` | **A3**: Almacén → Artículos → Exportar. **Sage**: Inventario → Artículos → Excel. **Holded**: Productos → Exportar CSV. **SAP**: MM60 o transacción SE16 tabla MARA. **Odoo**: Inventario → Productos → Exportar |
| `stock_actual.csv` | **A3**: Almacén → Stocks → Exportar. **Sage**: Inventario → Existencias. **Holded**: Productos → Stock. **SAP**: MMBE o MB52. **Odoo**: Inventario → Informes → Existencias |
| `clientes.csv` | **A3**: Ventas → Clientes → Exportar. **Sage**: Ventas → Clientes. **Holded**: Contactos → Clientes → Exportar. **SAP**: XD03 o tabla KNA1. **Odoo**: Contactos → Exportar |

## Nota importante

Este prompt está diseñado para el **sector mayorista y distribución** (suministros industriales, ferretería industrial, material eléctrico, fontanería, etc.). Las referencias, familias de producto y estructura de pedido siguen la lógica de este sector.

Para otros sectores (alimentación, textil, farmacia), ajusta las columnas del catálogo y las familias de producto a tu nomenclatura.

---

Creado por Isaac Romà · https://isaacroma.com
